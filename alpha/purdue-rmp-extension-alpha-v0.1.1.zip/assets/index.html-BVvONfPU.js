import"./modulepreload-polyfill-B5Qt9EMX.js";console.log("[Purdue RMP] options page loaded");
